import UIKit

var greeting = "Hello, playground"
var age = 23
print(greeting)
print("i wanna say" +  greeting)

let eyeColor = "blue"
print(eyeColor)
//eyeColor = "green"
print(eyeColor)

var message: String = "this is a string" //explicite type declaratio n

 
