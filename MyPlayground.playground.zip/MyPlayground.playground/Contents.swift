import UIKit
var greeting = "Hello, playground"
var message = "Hello, World!"
print(message)

// Person
var name = "Bob" // string
var age = 32 // integer
var weight = 200.34 // Double
var isOrganDonor = false // Boolean

print(weight)

weight = 180
print(weight)

let eyeColor = "blue"

var msg: String = "This is a string" // Explicite type declaration
var toMsg: String

toMsg = message + " " + name
print(toMsg)

var age2 = 20
var newMessage = "Hi, my name is \(name) and i am \(age2) years old"
newMessage.append(".and i like Coding.")

// now we code with numbers
var monAge = 15 // integer
var price = 12.33 // Double
var aPrice: Float = 12.33
var personeAge: Int = 15
var thePrice: Double = 12.33

var lenght = 10
var width = 5
let area = lenght * width //Multiplication
print(area)
 
var health = 100
var poisonDamage = 15
health = health - poisonDamage //Substraction
print(health)


var potion = 20
health += potion // Addition Coumpound assigne;ent operator
health = health + potion

var students = 30
var treats = 500
let treatPerStudent = treats / students //division
print(treatPerStudent)

let remainder = treats % students //modulo or remainder
print(remainder)

var tLenght: Double = 10
var tWidth: Double = 5
let arearTriangle = sqrt(pow(tLenght, 2) + pow(tWidth, 2))
print(area)
