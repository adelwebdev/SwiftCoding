import UIKit

var greeting = "Hello, playground"

let allowedEntry = false

if allowedEntry != true {
    print("Access denied")
}

