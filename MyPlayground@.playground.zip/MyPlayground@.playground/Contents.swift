import UIKit

var greeting = "Hello, playground"

var quantity: Int = 5
var productPrice:Double = 12.66

var const = Double(quantity) * productPrice

var amItheBestTeacherEver:Bool = true

amItheBestTeacherEver = false

if true == false || true == true {
    print("WTFish")
}

var hasDataFinishDownloading:Bool = false
//....
//....
hasDataFinishDownloading = true
//load UI

if 1 == 2 {
    print("Should not see this")
}

//Equal to: ==
// Not equal to: !=
//Greater than or equal to: >=
//Less than or equal to: <=

var bankBalance = 400
var itemToBuy = 400

if bankBalance >= itemToBuy {
    print("Purchased item")
}
if itemToBuy >= bankBalance {
    print("You need more money foo")
}
if itemToBuy == bankBalance {
    print("Hey buddy, you balance is now 0")
}
var amIAtZero = itemToBuy == bankBalance


var bookTitle1 = "Harry Blotter and the moppet of Mire"
var bookTitle2 = "Harry Blotter and the moppet of Mire"

if bookTitle1 != bookTitle2 {
    print("Need to fix spelling before printing")
} else if bookTitle2.characters.count > 10 {
    print("Find a new title for the book")
}
else {
    print("Book looks great send to printer")
}

if !hasDataFinishDownloading {
    print("Loading data...")
}

